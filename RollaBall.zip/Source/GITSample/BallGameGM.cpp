// Fill out your copyright notice in the Description page of Project Settings.


#include "BallGameGM.h"
#include "BallPlayer.h"
#include "Kismet/GameplayStatics.h"

ABallGameGM::ABallGameGM()
{
	//Class Name
	DefaultPawnClass = ABallPlayer::StaticClass();
}

void ABallGameGM::CheckNextLevel()
{
	TArray<AActor*> OutActors;
	UGameplayStatics::GetAllActorsWithTag(GetWorld(), TEXT("Coin"), OutActors);

	if (OutActors.Num() == 0)
	{
		UE_LOG(LogClass, Warning, TEXT("Clear Stage"));
		//CheckNextLevel_BlueprintImplement();
		CheckNextLevel_BlueprintNative();
		//���� �۾��� �� ��������Ʈ
		//UGameplayStatics::OpenLevel(GetWorld(), TEXT("Level02"));
	}
}

void ABallGameGM::CheckNextLevel_BlueprintNative_Implementation()
{
	//�⺻ ����
	//��Ʈ�� ��ȹ�ڸ� ������ �ȵ�
	UE_LOG(LogClass, Warning, TEXT("CheckNextLevel_BlueprintNative_Implementation"));

}
