// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "BallGameGM.generated.h"

/**
 * 
 */
UCLASS()
class GITSAMPLE_API ABallGameGM : public AGameModeBase
{
	GENERATED_BODY()

public:
	ABallGameGM(); //CDO Initialize
	
	UFUNCTION(BlueprintCallable)
	virtual void CheckNextLevel();

	//ȣ�� CPP, ���� ��������Ʈ
	UFUNCTION(BlueprintImplementableEvent)
	void CheckNextLevel_BlueprintImplement();

	//ȣ�� CPP, ���� ��������Ʈ, �⺻ ���� C++
	UFUNCTION(blueprintNativeEvent)
	void CheckNextLevel_BlueprintNative();
	void CheckNextLevel_BlueprintNative_Implementation();

};
